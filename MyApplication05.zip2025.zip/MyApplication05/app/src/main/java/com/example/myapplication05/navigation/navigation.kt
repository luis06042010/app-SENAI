package com.example.myapplication05.navigation

sealed class AppScreen(val route: String) {
    object Home : AppScreen("home")
    object Details : AppScreen("details")
    object Settings : AppScreen("settings")
    object Profile : AppScreen("profile/{userId}") {
        fun createRoute(userId: String) = "profile/$userId"
    }
}


